<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Y/LHgWCltSwt9Ii7lv7dl9nUrcm20GzVG66PA3XIp9fPNPxKdj2/25jgSFyros3AhgJBTSrPGEboSlOU3raG+g==');
define('SECURE_AUTH_KEY',  'avO82uT53FWUS7BQC545nKu4r85/BqIKAjUx8q5jkUc53IMSlYeXyf3lQ3sh4Vv4Wxen4ySRMDOfTbC9d6Mogw==');
define('LOGGED_IN_KEY',    'BHTTh3bon0U4VHxNTgpR1zfR5txLf/OnB0a3jOtNG9NF/ifVAsTdb65YTeHTjRvj+ySlZys3CCO5HtKyVj5N+A==');
define('NONCE_KEY',        '3P9iV5kwXtKaG/EOD/z845jb4uKh3lSslYPrzXFrfKKKoF888Fs99OqwCLKO9NoGGRtT9XtZR9JVOl1KGXmE0A==');
define('AUTH_SALT',        'PmnbhLmZOP62YSc5MfokNit1f06/8j/4XBKQ1qMsRjB9T8W6c4bXiklr1Ibme6t6FRHz83xE6aBz8GBIrvj7UA==');
define('SECURE_AUTH_SALT', 'ct2DPHkKn+Jwf2h0ZBq8f7CM7+cX1ak8kTbm3pcIGPMZpS7ED5S4p1sk0y92AN96NouPi/G1JY2XFMbAGzWb2w==');
define('LOGGED_IN_SALT',   'w6QwVWFCgJQFkNvGt0VqwQXJf5rGZgu4EXnH1ANTt1sDoOqBqc5WlYkmKDA2MO5xAOJ9zbWBCUt69xGy1caiLA==');
define('NONCE_SALT',       'n3q+aDxZ9bUcHu/l9lIe3mzQZwwq5g0i92vJcpZ8u89jpjr1TAN5kIn3Z51zOXh1p6gjArvCcjduU6WMwZ2YfQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
